class Mode(object):
    def __init__(self, name="", time=None, speedMult=1, direction=None):
        self.name = name
        self.time = time
        self.speedMult = speedMult
        self.direction = direction
